﻿using System;
using System.Drawing;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace papi
{
    public class Game1 : Game
    {
        public const int size_x = 80;
        public const int size_y = 40;
        public int timer = 0;
        public int timerpix = 0;
        public int Simmulatedparticles = 0;
        public int timerplayer = 0;
        public int FPS;
        public int btype = 1;
        public bool isPaused = false;
        public int brushSize = 1;
        private Microsoft.Xna.Framework.Color Selectedparticle;
        private string selected;
        bool alreadypressed = false;
        bool nooneplayers = true;
        private static readonly Random random = new();
        Random r = random;
        FrameCounter fc = new FrameCounter();

        public Game1()
        {
            Storage.GDM = new GraphicsDeviceManager(this)
            {
                GraphicsProfile = GraphicsProfile.Reach
            };
            Storage.CM = Content;
            Storage.game = this;
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            IsFixedTimeStep = true;
            Storage.GDM.IsFullScreen = true;
            TargetElapsedTime = TimeSpan.FromMilliseconds(11.1113333333333333333333333333333333333333333333333333); //60 frames/sec = 16.667ms pre frame
        }

        protected override void Initialize()
        {
            Storage.GDM.PreferredBackBufferWidth = 1920;
            Storage.GDM.PreferredBackBufferHeight = 1080;
            Storage.GDM.ApplyChanges();
            Storage.player = new Player[size_x, size_y];
            Storage.target = new RenderTarget2D(GraphicsDevice, size_x, size_y);
            Storage.targetBatch = new SpriteBatch(GraphicsDevice);
            Storage.particles = new Particle[size_x, size_y];
            Storage.maingamefont = Content.Load<SpriteFont>("andybold");
            Storage.drawRec = new Microsoft.Xna.Framework.Rectangle(0, 0, Storage.GDM.PreferredBackBufferWidth / size_x, Storage.GDM.PreferredBackBufferHeight / size_y);
            for (int x = 0; x < size_x; x++)
            {
                for (int y = 0; y < size_y; y++)
                {
                    Storage.particles[x, y] = null;
                }
            }


            base.Initialize();
        }

        protected override void LoadContent()
        {
            Storage.SB = new SpriteBatch(GraphicsDevice);
            if (Storage.texture == null)
            {
                // Texture used for drawing, will be scaled later.
                Storage.texture = new Texture2D(Storage.GDM.GraphicsDevice, 1, 1);
                Storage.texture.SetData<Microsoft.Xna.Framework.Color>(new Microsoft.Xna.Framework.Color[] { Microsoft.Xna.Framework.Color.SandyBrown });
            }

            // TODO: use this.Content to load your game content here
        }

        protected override void Update(GameTime gameTime)
        {
            var deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            fc.Update(deltaTime);
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            if (Keyboard.GetState().IsKeyDown(Keys.Tab))
            {
                for (int x = 0; x < size_x; x++)
                {
                    for (int y = 0; y < size_y; y++)
                    {
                        if (Storage.particles[x, y] != null)
                        {
                            Storage.particles[x, y] = null;
                            Simmulatedparticles = 0;
                        }
                        if (Storage.player[x, y] != null)
                        {
                            Storage.player[x, y] = null;
                        }
                    }
                }
                nooneplayers = true;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.NumPad1))
            {
                btype = 1;
                selected = "sand";
                Selectedparticle = Microsoft.Xna.Framework.Color.Yellow;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.NumPad2))
            {
                btype = 2;
                selected = "water";
                Selectedparticle = Microsoft.Xna.Framework.Color.Blue;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.NumPad3))
            {
                btype = 3;
                selected = "wall";
                Selectedparticle = Microsoft.Xna.Framework.Color.Gray;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.NumPad4))
            {
                btype = 4;
                selected = "dust";
                Selectedparticle = Microsoft.Xna.Framework.Color.IndianRed;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.NumPad5))
            {
                btype = 5;
                selected = "stone";
                Selectedparticle = Microsoft.Xna.Framework.Color.LightGray;
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.NumPad6))
            {
                btype = 6;
                selected = "acid(DANGER!!!)";
                Selectedparticle = Microsoft.Xna.Framework.Color.DarkGreen;
            }

            else if (Keyboard.GetState().IsKeyDown(Keys.P) && timer > 500)
            {
                timer = 0;
                if (isPaused == false)
                {
                    isPaused = true;
                }
                else
                {
                    isPaused = false;
                }
            }
            else if (Keyboard.GetState().IsKeyDown(Keys.F) && alreadypressed == false)
            {
                alreadypressed = true;
                if (Storage.GDM.IsFullScreen == false)
                {
                    Storage.GDM.PreferredBackBufferWidth = 1920;
                    Storage.GDM.PreferredBackBufferHeight = 1080;
                    Storage.GDM.IsFullScreen = true;
                    Storage.GDM.ApplyChanges();
                    Storage.drawRec = new Microsoft.Xna.Framework.Rectangle(0, 0, Storage.GDM.PreferredBackBufferWidth / size_x, Storage.GDM.PreferredBackBufferHeight / size_y);
                }
                else
                {
                    Storage.GDM.PreferredBackBufferWidth = 640;
                    Storage.GDM.PreferredBackBufferHeight = 360;
                    Storage.GDM.IsFullScreen = false;
                    Storage.GDM.ApplyChanges();
                    Storage.drawRec = new Microsoft.Xna.Framework.Rectangle(0, 0, Storage.GDM.PreferredBackBufferWidth / size_x, Storage.GDM.PreferredBackBufferHeight / size_y);
                }
            }
            if (Keyboard.GetState().IsKeyUp(Keys.F))
            {
                alreadypressed = false;
            }
            int timerphys = 0;
            timerphys += gameTime.ElapsedGameTime.Milliseconds;
            Simmulatedparticles = 0;
            for (int x = 0; x < size_x; x++)
            {
                for (int y = 0; y < size_y; y++)
                {
                    var particle = Storage.particles[x, y];
                    if (particle != null)
                    {
                        Simmulatedparticles += 1;
                    }
                    if (particle != null && isPaused == false)
                    {
                        particle.y_velocity += 1;
                        if (MathF.Abs(particle.y_velocity) > 1)
                        {
                            particle.y_velocity = 1 * Math.Sign(particle.y_velocity);
                        }

                        particle.x_velocity += 0;
                        if (MathF.Abs(particle.x_velocity) > 1)
                        {
                            particle.x_velocity = 1 * Math.Sign(particle.x_velocity);
                        }

                        int next_x = x + particle.x_velocity;
                        int next_y = y + particle.y_velocity;
                        if (!Find_collision(next_x, next_y) && !find_player(next_x, next_y))
                        {
                            // Go there.
                        }
                        else if (!Find_collision(next_x - 1, next_y) && !find_player(next_x - 1, next_y))
                        {
                            next_x -= 1;
                        }
                        else if (!Find_collision(next_x + 1, next_y) && !find_player(next_x + 1, next_y))
                        {
                            next_x += 1;
                        }

                        else
                        {
                            // Can't move.
                            next_x = x;
                            particle.x_velocity = 0;

                            next_y = y;
                            particle.y_velocity = 0;
                        }
                        // Simulate water. Move side to side if you can.
                        if (particle.type == 2)
                        {
                            particle.y_velocity += 1;
                            if (MathF.Abs(particle.y_velocity) > 1)
                            {
                                particle.y_velocity = 1 * Math.Sign(particle.y_velocity);
                            }

                            particle.x_velocity += r.Next(0, 1);
                            if (MathF.Abs(particle.x_velocity) > 1)
                            {
                                particle.x_velocity = 1 * Math.Sign(particle.x_velocity);
                            }
                            if (!Find_collision(next_x, next_y))
                            {
                                // Go there.
                            }
                            else if (!Find_collision(next_x - 1, next_y) && !find_player(next_x - 1, next_y))
                            {
                                next_x -= 1;
                            }
                            else if (!Find_collision(next_x + 1, next_y) && !find_player(next_x + 1, next_y))
                            {
                                next_x += 1;
                            }

                            else
                            {
                                // Can't move.
                                next_x = x;
                                particle.x_velocity = 0;

                                next_y = y;
                                particle.y_velocity = 0;
                            }
                        }
                        else if (particle.type == 3)
                        {
                            // Can't move.
                            next_x = x;
                            particle.x_velocity = 0;

                            next_y = y;
                            particle.y_velocity = 0;
                        }
                        else if (particle.type == 4 && timerphys > 75)
                        {
                            timerphys = 0;
                            if(!Find_collision(next_x, next_y))
                            {
                                next_x = r.Next(-1, 1);
                            }
                        }
                        else if (particle.type == 5)
                        {
                            // Can't move.
                            next_x = x;
                            particle.x_velocity = 0;
                        }
                        else if (particle.type == 6)
                            {
                                particle.y_velocity += 1;
                                if (MathF.Abs(particle.y_velocity) > 1)
                                {
                                    particle.y_velocity = 1 * Math.Sign(particle.y_velocity);
                                }

                                particle.x_velocity += r.Next(0, 1);
                                if (MathF.Abs(particle.x_velocity) > 1)
                                {
                                    particle.x_velocity = 1 * Math.Sign(particle.x_velocity);
                                }
                                if (!Find_collision(next_x, next_y))
                                {
                                    // Go there.
                                }
                                else if (!Find_collision(next_x - 1, next_y) && !find_player(next_x - 1, next_y))
                                {
                                    next_x -= 1;
                                }
                                else if (!Find_collision(next_x + 1, next_y) && !find_player(next_x + 1, next_y))
                                {
                                    next_x += 1;
                                }

                                else
                                {
                                    // Can't move.
                                    next_x = x;
                                    particle.x_velocity = 0;

                                    next_y = y;
                                    particle.y_velocity = 0;
                                if((x - 1) > 0 && Storage.particles[x - 1, y] != null && Storage.particles[x - 1, y].type != 6)
                                    Storage.particles[x - 1, y] = null;

                                if ((x + 1) < size_x && Storage.particles[x + 1, y] != null && Storage.particles[x + 1, y].type != 6)
                                    Storage.particles[x + 1, y] = null;
     

                                if ((y - 1) > 0 && Storage.particles[x, y - 1] != null && Storage.particles[x, y - 1].type != 6)
                                    Storage.particles[x, y - 1] = null;

                                if ((y + 1) < size_y &&  Storage.particles[x, y + 1] != null && Storage.particles[x, y + 1].type != 6)
                                    Storage.particles[x, y + 1] = null;

                            }
                            }
                        Storage.particles[x, y] = null;
                        x = next_x;
                        y = next_y;
                        Storage.particles[x, y] = particle;
                    }
                }
            }
            timer += gameTime.ElapsedGameTime.Milliseconds;
            timerpix += gameTime.ElapsedGameTime.Milliseconds;
            timerplayer += gameTime.ElapsedGameTime.Milliseconds;
            for (int xp = 0; xp < size_x; xp++)
            {
                for (int yp = 0; yp < size_y; yp++)
                {
                    var player = Storage.player[xp, yp];
                    if (player != null && isPaused == false)
                    {
                        player.vy -= player.ax;
                        if(timerplayer > 50)
                        {
                            timerplayer = 0;
                            player.ax -= 1;
                        }
                        if (MathF.Abs(player.vy) > 1)
                        {
                            player.vy = 1 * Math.Sign(player.vy);
                        }

                        player.vx += 0;
                        if (MathF.Abs(player.vx) > 1)
                        {
                            player.vx = 1 * Math.Sign(player.vx);
                        }

                        int next_xp = xp + player.vx;
                        int next_yp = yp + player.vy;
                        if (!Find_collision(next_xp, next_yp))
                        {
                            player.isGround = false;
                        }
                        //else if (!find_collision(next_xp - 1, next_yp))
                        //{
                         //   next_xp -= 1;
                       // }
                        //else if (!find_collision(next_xp + 1, next_yp))
                        //{
                         //   next_xp += 1;
                        //}

                        else
                        {
                            // Can't move.
                            next_xp = xp;
                            player.vx = 0;
                            player.isGround = true;

                            next_yp = yp;
                            player.vy = 0;
                        }

                        if (Keyboard.GetState().IsKeyDown(Keys.D) && !Find_collision(xp + 1, yp) && timerpix > 50)
                        {
                            timerpix = 0;
                            next_xp += 1;
                        }
                        if (Keyboard.GetState().IsKeyDown(Keys.A) && !Find_collision(xp - 1, yp) && timerpix > 50)
                        {
                            next_xp -= 1;
                            timerpix = 0;
                        }
                        if (Keyboard.GetState().IsKeyDown(Keys.Space) && player.isGround == true)
                        {
                            player.ax = 1;
                        }
                        Storage.player[xp, yp] = null;
                        xp = next_xp;
                        yp = next_yp;
                        Storage.player[xp, yp] = player;
                    }
                }
            }
            //player physics

            // Delay how fast you can create particles.
            var mouse_state = Mouse.GetState();
            if (mouse_state.LeftButton == ButtonState.Pressed)
            {
                var x = mouse_state.Position.X * size_x / Storage.GDM.PreferredBackBufferWidth;
                var y = mouse_state.Position.Y * size_y / Storage.GDM.PreferredBackBufferHeight;
                // Only create a particle in this grid location if nothing is currently there.
                for (int e = 0; e < brushSize; e++)
                {
                    for (int b = 0; b < brushSize; b++)
                    {
                        int rp = r.Next(0, 1);
                        if ((x + e) >= 0 && (x + e) < size_x && (y + b) >= 0 && (y + b) < size_y && Storage.particles[(x + e), (y + b)] == null && rp == 0)
                        {
                            Particle particle = new Particle();
                            particle.type = btype;
                            if (particle.type == 1)
                            {
                                particle.color = new Microsoft.Xna.Framework.Color(r.Next(207, 227), r.Next(204, 224), r.Next(110, 130));
                            }
                            else if (particle.type == 2)
                            {
                                particle.color = new Microsoft.Xna.Framework.Color(36, 54, r.Next(195, 245));
                            }
                            else if (particle.type == 3)
                            {
                                int kakab = r.Next(240, 255);
                                particle.color = new Microsoft.Xna.Framework.Color(kakab, kakab, kakab);
                            }
                            else if (particle.type == 4)
                            {
                                particle.color = new Microsoft.Xna.Framework.Color(r.Next(100, 255), r.Next(100, 255), r.Next(100, 255));
                            }
                            else if (particle.type == 5)
                            {
                                int kakab = r.Next(170, 190);
                                particle.color = new Microsoft.Xna.Framework.Color(r.Next(135, 150), kakab, kakab);
                            }
                            else if (particle.type == 6)
                            {
                                particle.color = Microsoft.Xna.Framework.Color.LimeGreen;
                            }
                            Storage.particles[x + e, y + b] = particle;
                        }
                    }
                }
            }
            if(mouse_state.RightButton == ButtonState.Pressed)
            {
                var x = mouse_state.Position.X * size_x / Storage.GDM.PreferredBackBufferWidth;
                var y = mouse_state.Position.Y * size_y / Storage.GDM.PreferredBackBufferHeight;
                if (x >= 0 && x < size_x && y >= 0 && y < size_y && Storage.particles[x, y] != null)
                {
                    Storage.particles[x, y] = null;
                }
            }
            if(Keyboard.GetState().IsKeyDown(Keys.G)&& timer > 500)
            {
                var x = mouse_state.Position.X * size_x / Storage.GDM.PreferredBackBufferWidth;
                var y = mouse_state.Position.Y * size_y / Storage.GDM.PreferredBackBufferHeight;
                timer = 0;
                if (Storage.player[x, y] == null)
                {
                    Storage.player[x, y] = new();
                }
                nooneplayers = false;
            }

            base.Update(gameTime);
        }

        private static bool Find_collision(int x, int y)
        {
            if (y >= size_y || y <= -1)
            {
                return true;
            }
            if (x <= -1 || x >= size_x)
            {
                return true;
            }
            return Storage.particles[x, y] != null;
        }
        private static bool find_player(int x, int y)
        {
            return Storage.player[x, y] != null;
        }
        bool Is_liquid(int x, int y)
        {
            return Storage.particles[x, y].type == 2;
        }
        bool find_afk(int x, int y)
        {
            if (Storage.particles[x, y] != null)
            {
                //if(find_collision(x + 1, y) && find_collision(x - 1, y) && find_collision(x, y + 1) && find_collision(x, y - 1))
                //{
                    return true;
                //}
            }
            return Storage.particles[x, y].y_velocity == 100;
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Microsoft.Xna.Framework.Color.Black);

            Storage.SB.Begin();
            for (int x = 0; x < size_x; x++)
            {
                for (int y = 0; y < size_y; y++)
                {
                    Particle particle = Storage.particles[x, y];
                    if (particle != null)
                    {
                        Vector2 pos = new Vector2(x * (Storage.GDM.PreferredBackBufferWidth / size_x), y * (Storage.GDM.PreferredBackBufferHeight / size_y));
                        //Draw each particle as a sprite.
                        Storage.SB.Draw(Storage.texture,
                            pos,
                            Storage.drawRec,
                            particle.color,
                            0,
                            Vector2.Zero,
                            1f, // Scale
                            SpriteEffects.None,
                           0.000f);
                    }
                }
            }
            for (int xp = 0; xp < size_x; xp++)
            {
                for (int yp = 0; yp < size_y; yp++)
                {
                    //depth += 1;
                    var player = Storage.player[xp, yp];
                    if (player != null)
                    {
                        Vector2 pos = new Vector2(xp * (Storage.GDM.PreferredBackBufferWidth / size_x), yp * (Storage.GDM.PreferredBackBufferHeight / size_y));
                        //Draw each particle as a sprite.
                        Storage.SB.Draw(Storage.texture,
                            pos,
                            Storage.drawRec,
                            player.color,
                            0,
                            Vector2.Zero,
                            1f, // Scale
                            SpriteEffects.None,
                           0.000f);
                    }
                }
            }
            Storage.SB.DrawString(Storage.maingamefont, Simmulatedparticles + " particles simulated", new Vector2(0, 0), Microsoft.Xna.Framework.Color.White);
            Storage.SB.DrawString(Storage.maingamefont, fc.CurrentFramesPerSecond + " FPS", new Vector2(0, 32), Microsoft.Xna.Framework.Color.White);
            Storage.SB.DrawString(Storage.maingamefont, "selected " + selected, new Vector2(0, 64), Selectedparticle);
            if(nooneplayers == true)
            {
                Storage.SB.DrawString(Storage.maingamefont, "press G to spawn player", new Vector2(Storage.GDM.PreferredBackBufferWidth - 320, Storage.GDM.PreferredBackBufferHeight - 36), Microsoft.Xna.Framework.Color.Gray);
            }
            Storage.SB.End();

            base.Draw(gameTime);
        }
    }
}
