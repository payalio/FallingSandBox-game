﻿
using var game = new papi.Game1();
game.Run();
